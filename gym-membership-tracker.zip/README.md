# Gym Membership Tracker — Project Topic #6

This implementation uses **PHP 8 + SQLite + HTML/CSS/JavaScript**. The PHP backend talks to the SQLite database; the browser interface is in `index.html`. Python is not needed.

## Requirements and run steps

- PHP 8.1 or newer with `pdo_sqlite` enabled.
- From this folder, run `php -S 127.0.0.1:8001 router.php`.
- Open <http://127.0.0.1:8001> in a browser.
- Stop the server with `Ctrl+C`.

On first run, the app creates `gym.db` and seeds fictional demo data. Keep that file to retain changes. Remove it only to reset the demo data.

## Functions

- Create memberships and record initial plan payments.
- Assign or change trainers.
- Renew a membership, extend its expiry date, and record the renewal payment.
- Record monthly dues and payment method.
- Search/filter members and view expiring memberships, expected monthly dues, trainer workload, and recent payments.

## Technology choices

The project guide permits:

| Layer | Options | Included |
| --- | --- | --- |
| Database | MySQL, PostgreSQL, SQLite, MS Access | SQLite |
| Interface | HTML/CSS/JS, Python Tkinter/Flask, Java Swing, PHP | HTML/CSS/JS with PHP backend |

To change the database, adapt the PDO connection and SQL dialect in `index.php` and `schema.sql`.

## Relational schema

```text
Trainers(trainer_id PK, trainer_code UNIQUE, full_name, specialty, phone UNIQUE)
Plans(plan_id PK, plan_name UNIQUE, duration_months, monthly_fee, description)
Members(member_id PK, member_code UNIQUE, full_name, email UNIQUE, phone UNIQUE,
        join_date, expiry_date, plan_id FK, trainer_id FK nullable, active)
Payment_History(payment_id PK, member_id FK, plan_id FK, amount, payment_date,
                payment_for, payment_method, reference_no UNIQUE)
```

Relationships: one plan has many members and payments; one trainer can coach many members; one member has many payment records. Trainers are optional. Foreign keys maintain relationships; `CHECK` constraints validate plan duration, fee, active flag, payment amount, and payment type. Indexes support expiry and member payment lookups. `member_directory` is a reporting view joining the member, plan, and trainer details.

### Normalization summary

- **1NF:** Each field stores one value; each payment is a separate row.
- **2NF:** Non-key fields depend on the primary key for their entity. Payment details are separate from member and plan details.
- **3NF:** Plan prices and trainer specialties live in their own tables; members and payments reference them rather than repeating descriptive data.

## Example queries

```sql
-- Memberships expiring within 14 days
SELECT member_code, full_name, plan_name, expiry_date, trainer_name
FROM member_directory
WHERE expiry_date BETWEEN date('now') AND date('now', '+14 day')
ORDER BY expiry_date;

-- Collection this month by payment type
SELECT payment_for, SUM(amount) AS total_collected, COUNT(*) AS transactions
FROM payment_history
WHERE strftime('%Y-%m', payment_date) = strftime('%Y-%m', 'now')
GROUP BY payment_for;
```

## Submission notes

The guide asks for a 10–15 page report and a 10–12 slide presentation. Add your real group number, 3–4 members' names/enrollment numbers/roles, faculty name, department, and submission date. Demo flow: add a member, show the initial payment, assign a trainer, renew, record monthly dues, then show the expiry dashboard and payment rows. Use screenshots of the running UI and populated database. The included contact details are fictional demo data and should be replaced with approved project data before submission.

Future enhancements could include authentication, check-in scanning, automated reminders, downloadable reports, and cloud deployment.
