<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Kolkata');
$databaseFile = __DIR__ . '/gym.db';

function db(): PDO {
    global $databaseFile;
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('sqlite:' . $databaseFile, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec('PRAGMA foreign_keys = ON');
    }
    return $pdo;
}

function respond(array $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function initializeDatabase(): void {
    $pdo = db();
    $pdo->exec(file_get_contents(__DIR__ . '/schema.sql'));
    if ((int)$pdo->query('SELECT COUNT(*) FROM trainers')->fetchColumn() !== 0) return;

    $pdo->beginTransaction();
    try {
        $trainerInsert = $pdo->prepare('INSERT INTO trainers(trainer_code,full_name,specialty,phone) VALUES(?,?,?,?)');
        foreach ([
            ['TR-101','Anaya Kapoor','Strength & Conditioning','9876501001'],
            ['TR-102','Arjun Nair','Functional Training','9876501002'],
            ['TR-103','Ishita Rao','Yoga & Mobility','9876501003'],
        ] as $trainer) $trainerInsert->execute($trainer);

        $planInsert = $pdo->prepare('INSERT INTO plans(plan_name,duration_months,monthly_fee,description) VALUES(?,?,?,?)');
        foreach ([
            ['Monthly',1,1800,'Flexible month-to-month access'],
            ['Quarterly',3,1600,'Three-month membership, billed monthly'],
            ['Annual',12,1300,'Best value, one-year membership'],
        ] as $plan) $planInsert->execute($plan);

        $today = new DateTimeImmutable('today');
        $demo = [
            ['GM-2401','Riya Sharma','riya@example.edu','9876502001',-82,1,1,1800,1],
            ['GM-2402','Dev Malhotra','dev@example.edu','9876502002',-36,2,2,4800,3],
            ['GM-2403','Sara Khan','sara@example.edu','9876502003',9,1,3,1800,1],
            ['GM-2404','Vivaan Patel','vivaan@example.edu','9876502004',48,3,1,15600,12],
            ['GM-2405','Aanya Iyer','aanya@example.edu','9876502005',-3,2,2,4800,3],
            ['GM-2406','Kabir Mehta','kabir@example.edu','9876502006',77,3,null,15600,12],
        ];
        $memberInsert = $pdo->prepare('INSERT INTO members(member_code,full_name,email,phone,join_date,expiry_date,plan_id,trainer_id) VALUES(?,?,?,?,?,?,?,?)');
        $paymentInsert = $pdo->prepare("INSERT INTO payment_history(member_id,plan_id,amount,payment_date,payment_for,payment_method) VALUES(?,?,?,?,?,'Card')");
        foreach ($demo as [$code,$name,$email,$phone,$offset,$planId,$trainerId,$amount,$months]) {
            $expiry = $today->modify(($offset >= 0 ? '+' : '') . $offset . ' days');
            $joined = $expiry->modify('-' . (30 * $months) . ' days');
            $memberInsert->execute([$code,$name,$email,$phone,$joined->format('Y-m-d'),$expiry->format('Y-m-d'),$planId,$trainerId]);
            $paymentInsert->execute([(int)$pdo->lastInsertId(),$planId,$amount,$today->modify('-20 days')->format('Y-m-d'),'New membership']);
        }
        $pdo->commit();
    } catch (Throwable $error) {
        $pdo->rollBack();
        throw $error;
    }
}

function requestBody(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '', true);
    if (!is_array($data)) respond(['error' => 'Invalid request data.'], 400);
    return $data;
}

function addMonths(DateTimeImmutable $day, int $months): DateTimeImmutable {
    $target = $day->modify('first day of this month')->modify(($months >= 0 ? '+' : '') . $months . ' months');
    $lastDay = (int)$target->format('t');
    return $target->setDate((int)$target->format('Y'), (int)$target->format('m'), min((int)$day->format('d'), $lastDay));
}

try {
    initializeDatabase();
    $pdo = db();
    $route = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';

    if ($_SERVER['REQUEST_METHOD'] === 'GET' && $route === '/api/overview') {
        $members = $pdo->query("SELECT *,CASE WHEN active=0 OR expiry_date<date('now','localtime') THEN 'expired' WHEN expiry_date<=date('now','+14 day','localtime') THEN 'expiring' ELSE 'active' END status FROM member_directory ORDER BY expiry_date")->fetchAll();
        $plans = $pdo->query('SELECT * FROM plans ORDER BY duration_months')->fetchAll();
        $trainers = $pdo->query('SELECT t.*,COUNT(m.member_id) member_count FROM trainers t LEFT JOIN members m ON m.trainer_id=t.trainer_id AND m.active=1 GROUP BY t.trainer_id ORDER BY t.full_name')->fetchAll();
        $payments = $pdo->query('SELECT ph.*,m.full_name,m.member_code FROM payment_history ph JOIN members m ON m.member_id=ph.member_id ORDER BY payment_date DESC,payment_id DESC LIMIT 6')->fetchAll();
        $active = count(array_filter($members, fn($m) => $m['status'] !== 'expired'));
        $due = count(array_filter($members, fn($m) => in_array($m['status'], ['expired','expiring'], true)));
        $monthlyDues = array_sum(array_map(fn($m) => $m['status'] !== 'expired' ? (float)$m['monthly_fee'] : 0.0, $members));
        $collected = (float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payment_history WHERE strftime('%Y-%m',payment_date)=strftime('%Y-%m','now','localtime')")->fetchColumn();
        respond(['members'=>$members,'plans'=>$plans,'trainers'=>$trainers,'payments'=>$payments,'active_count'=>$active,'due_count'=>$due,'monthly_dues'=>$monthlyDues,'collected'=>$collected]);
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') respond(['error'=>'Not found'],404);
    $data = requestBody();
    $today = new DateTimeImmutable('today');
    $todayText = $today->format('Y-m-d');

    if ($route === '/api/members') {
        $planQuery=$pdo->prepare('SELECT * FROM plans WHERE plan_id=?');$planQuery->execute([(int)($data['plan_id']??0)]);$plan=$planQuery->fetch();
        if (!$plan) respond(['error'=>'Select a valid plan.'],400);
        $code='GM-' . strtoupper(bin2hex(random_bytes(3)));
        $trainer=empty($data['trainer_id'])?null:(int)$data['trainer_id'];
        $expiry=addMonths($today,(int)$plan['duration_months'])->format('Y-m-d');
        $pdo->beginTransaction();
        $insert=$pdo->prepare('INSERT INTO members(member_code,full_name,email,phone,join_date,expiry_date,plan_id,trainer_id) VALUES(?,?,?,?,?,?,?,?)');
        $insert->execute([$code,trim((string)($data['full_name']??'')),trim((string)($data['email']??'')),trim((string)($data['phone']??'')),$todayText,$expiry,(int)$plan['plan_id'],$trainer]);
        $payment=$pdo->prepare("INSERT INTO payment_history(member_id,plan_id,amount,payment_date,payment_for,payment_method,reference_no) VALUES(?,?,?,?,? ,?,?)");
        $payment->execute([(int)$pdo->lastInsertId(),(int)$plan['plan_id'],(float)$plan['monthly_fee']*(int)$plan['duration_months'],$todayText,'New membership',(string)($data['payment_method']??'Cash'),strtoupper(bin2hex(random_bytes(5)))]);
        $pdo->commit();respond(['created'=>true,'member_code'=>$code],201);
    }

    if ($route === '/api/renew') {
        $memberId=(int)($data['member_id']??0);$planId=(int)($data['plan_id']??0);
        $mQuery=$pdo->prepare('SELECT * FROM members WHERE member_id=?');$mQuery->execute([$memberId]);$member=$mQuery->fetch();
        $pQuery=$pdo->prepare('SELECT * FROM plans WHERE plan_id=?');$pQuery->execute([$planId]);$plan=$pQuery->fetch();
        if (!$member||!$plan) respond(['error'=>'Member or plan not found.'],404);
        $expiry=DateTimeImmutable::createFromFormat('!Y-m-d',$member['expiry_date']) ?: $today;
        $start=$expiry>$today?$expiry:$today;
        $newExpiry=addMonths($start,(int)$plan['duration_months'])->format('Y-m-d');
        $pdo->beginTransaction();
        $update=$pdo->prepare('UPDATE members SET plan_id=?,expiry_date=?,active=1 WHERE member_id=?');$update->execute([$planId,$newExpiry,$memberId]);
        $payment=$pdo->prepare("INSERT INTO payment_history(member_id,plan_id,amount,payment_date,payment_for,payment_method,reference_no) VALUES(?,?,?,?,?,?,?)");
        $payment->execute([$memberId,$planId,(float)$plan['monthly_fee']*(int)$plan['duration_months'],$todayText,'Renewal',(string)($data['payment_method']??'Cash'),strtoupper(bin2hex(random_bytes(5)))]);
        $pdo->commit();respond(['renewed'=>true]);
    }

    if ($route === '/api/dues') {
        $memberId=(int)($data['member_id']??0);$amount=(float)($data['amount']??-1);
        if ($amount<0) respond(['error'=>'Amount cannot be negative.'],400);
        $mQuery=$pdo->prepare('SELECT plan_id FROM members WHERE member_id=?');$mQuery->execute([$memberId]);$member=$mQuery->fetch();
        if (!$member) respond(['error'=>'Member not found.'],404);
        $payment=$pdo->prepare("INSERT INTO payment_history(member_id,plan_id,amount,payment_date,payment_for,payment_method,reference_no) VALUES(?,?,?,?,?,?,?)");
        $payment->execute([$memberId,(int)$member['plan_id'],$amount,$todayText,'Monthly dues',(string)($data['payment_method']??'Cash'),strtoupper(bin2hex(random_bytes(5)))]);
        respond(['recorded'=>true]);
    }

    if ($route === '/api/assign') {
        $trainer=empty($data['trainer_id'])?null:(int)$data['trainer_id'];
        $update=$pdo->prepare('UPDATE members SET trainer_id=? WHERE member_id=?');$update->execute([$trainer,(int)($data['member_id']??0)]);
        if ($update->rowCount()===0 && !$pdo->query('SELECT 1')->fetchColumn()) respond(['error'=>'Member not found.'],404);
        respond(['assigned'=>true]);
    }

    respond(['error'=>'Not found'],404);
} catch (PDOException $error) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    if (str_contains($error->getMessage(),'UNIQUE constraint failed')) respond(['error'=>'A member with that email or phone already exists.'],400);
    respond(['error'=>'Database error: ' . $error->getMessage()],500);
} catch (Throwable $error) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    respond(['error'=>$error->getMessage()],500);
}
