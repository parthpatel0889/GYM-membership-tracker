PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS trainers (
    trainer_id INTEGER PRIMARY KEY,
    trainer_code TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    specialty TEXT NOT NULL,
    phone TEXT UNIQUE
);

CREATE TABLE IF NOT EXISTS plans (
    plan_id INTEGER PRIMARY KEY,
    plan_name TEXT NOT NULL UNIQUE,
    duration_months INTEGER NOT NULL CHECK(duration_months > 0),
    monthly_fee REAL NOT NULL CHECK(monthly_fee >= 0),
    description TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS members (
    member_id INTEGER PRIMARY KEY,
    member_code TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT NOT NULL UNIQUE,
    join_date TEXT NOT NULL,
    expiry_date TEXT NOT NULL,
    plan_id INTEGER NOT NULL,
    trainer_id INTEGER,
    active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
    FOREIGN KEY(plan_id) REFERENCES plans(plan_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY(trainer_id) REFERENCES trainers(trainer_id) ON UPDATE CASCADE ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS payment_history (
    payment_id INTEGER PRIMARY KEY,
    member_id INTEGER NOT NULL,
    plan_id INTEGER NOT NULL,
    amount REAL NOT NULL CHECK(amount >= 0),
    payment_date TEXT NOT NULL,
    payment_for TEXT NOT NULL CHECK(payment_for IN ('New membership','Renewal','Monthly dues')),
    payment_method TEXT NOT NULL DEFAULT 'Cash',
    reference_no TEXT UNIQUE,
    FOREIGN KEY(member_id) REFERENCES members(member_id) ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY(plan_id) REFERENCES plans(plan_id) ON UPDATE CASCADE ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_members_expiry ON members(expiry_date,active);
CREATE INDEX IF NOT EXISTS idx_payments_member_date ON payment_history(member_id,payment_date);

CREATE VIEW IF NOT EXISTS member_directory AS
SELECT m.member_id,m.member_code,m.full_name,m.email,m.phone,m.join_date,m.expiry_date,
       m.active,p.plan_name,p.duration_months,p.monthly_fee,
       t.full_name AS trainer_name,t.trainer_id
FROM members m JOIN plans p ON p.plan_id=m.plan_id
LEFT JOIN trainers t ON t.trainer_id=m.trainer_id;
